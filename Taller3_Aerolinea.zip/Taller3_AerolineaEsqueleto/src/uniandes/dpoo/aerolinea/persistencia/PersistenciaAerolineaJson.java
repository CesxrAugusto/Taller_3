package uniandes.dpoo.aerolinea.persistencia;

import java.io.IOException;

import uniandes.dpoo.aerolinea.modelo.Aerolinea;

public class PersistenciaAerolineaJson implements IPersistenciaAerolinea{
	
	public void cargarAerolinea(String archivo, Aerolinea aerolinea) {
		
	}

	@Override
	public void salvarAerolinea(String arhicvo, Aerolinea aerolinea) throws IOException {
		// TODO Auto-generated method stub	
	}
}
