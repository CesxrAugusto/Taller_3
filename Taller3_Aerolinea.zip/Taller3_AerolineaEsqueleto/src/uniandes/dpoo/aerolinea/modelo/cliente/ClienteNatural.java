package uniandes.dpoo.aerolinea.modelo.cliente;

public class ClienteNatural extends Cliente{
	
	public static String NATURAL = "Natural";
	private String nombre;
	private static int numCliente = 1;
	private String identificador;
	
	public ClienteNatural(String pNombre) {
		this.nombre = pNombre;
		this.identificador = Integer.toString(numCliente) + ". " + this.nombre;
		numCliente += 1;
	}
	
	@Override
	public String getIdentificador() {
		return identificador;
	}

	@Override
	public String getTipoCliente() {
		return NATURAL;
	}
	

}
