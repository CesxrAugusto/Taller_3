package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.List;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public abstract class Cliente {
	private List<Tiquete> tiquetesSinUsar;
	private List<Tiquete> tiquetesUsados;
	
	Cliente(){
				
	}
	
	public void agregarTiquete(Tiquete tiquete) {
		tiquetesSinUsar.add(tiquete);
	}
	
	public void usarTiquetes(Vuelo vuelo) {
		for(int i = 0; i < tiquetesSinUsar.size(); i++) {
			 if (tiquetesSinUsar.get(i).getVuelo().equals(vuelo)) {
				tiquetesSinUsar.get(i).marcarComoUsado();
				Tiquete tiqueteAgregar = tiquetesSinUsar.remove(i);
				tiquetesUsados.add(tiqueteAgregar);
				
			 }
		}
	}
	
	public int calcularValorTotalTiquetes() {
		int valor_total = 0;
		for(int i = 0; i < tiquetesSinUsar.size(); i++) {
			valor_total += tiquetesSinUsar.get(i).getTarifa();
		}
		for(int i = 0; i < tiquetesUsados.size(); i++) {
			valor_total += tiquetesUsados.get(i).getTarifa();
		}
		return valor_total;
	}
	
	public abstract String getIdentificador();
	public abstract String getTipoCliente();
	
}
