package uniandes.dpoo.aerolinea.modelo;

public class Avion {
	
	private String nombre;
	private int capacidad;
	
	public Avion(String pNombre, int pCapacidad) {
		this.nombre = pNombre;
		this.capacidad = pCapacidad;
	}

	public String getNombre() {
		return nombre;
	}

	public int getCapacidad() {
		return capacidad;
	}
}
