package uniandes.dpoo.aerolinea.modelo;

import java.util.Collection;
import java.util.HashMap;
import uniandes.dpoo.aerolinea.exceptions.VueloSobrevendidoException;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tiquetes.GeneradorTiquetes;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo {

	private String fecha;
	private Ruta ruta;
	private Avion avion;
	private HashMap<String, Tiquete> tiquetes;
	
	public Vuelo(Ruta pRuta, String pFecha, Avion pAvion) {
		this.fecha = pFecha;
		this.ruta = pRuta;
		this.avion = pAvion;
		this.tiquetes = new HashMap<String, Tiquete>();
	}

	public String getFecha() {
		return fecha;
	}

	public Ruta getRuta() {
		return ruta;
	}

	public Avion getAvion() {
		return avion;
	}
	
	public Collection<Tiquete> getTiquetes(){
		return tiquetes.values();
	}
	
	public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad) throws VueloSobrevendidoException {
			if(this.avion.getCapacidad() >= this.getTiquetes().size() + cantidad){
			int valor_total = 0;
			for(int i=0; i<cantidad; i++) {
				int tarifa = calculadora.calcularTarifa(this, cliente);
				Tiquete nuevoTiquete = GeneradorTiquetes.generarTiquete(this, cliente, tarifa);
				tiquetes.put(nuevoTiquete.getCodigo(), nuevoTiquete);
				GeneradorTiquetes.registrarTiquete(nuevoTiquete);
				valor_total += tarifa;
			}
			return valor_total;
			} else {
				throw new VueloSobrevendidoException(this);
			}
			
		}
	
	@Override
	public boolean equals(Object obj) {
		boolean retorno = true;
		if(obj == null) {
			retorno = false;
		}
		else if(this.getClass() == obj.getClass()) {
			retorno = false;
		}
		else {
			Vuelo objeto_comparable = (Vuelo) obj;
			if (!((objeto_comparable.avion == this.avion) && (objeto_comparable.fecha == this.fecha) && (objeto_comparable.ruta == this.ruta))) {
				retorno = false;
			}
		}
		return retorno;
	}
}

