package uniandes.dpoo.aerolinea.tiquetes;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class Tiquete{
	private String codigo;
	private int tarifa;
	private boolean usado = false;
	private Cliente cliente;
	private Vuelo vuelo;
	
	public Tiquete(String pCodigo, Vuelo pVuelo, Cliente clienteComprador, int tarifa) {
		this.codigo = pCodigo;
		this.vuelo = pVuelo;
		this.cliente = clienteComprador;
		this.tarifa = tarifa;
	}

	public int getTarifa() {
		return tarifa;
	}

	public void setTarifa(int tarifa) {
		this.tarifa = tarifa;
	}

	public String getCodigo() {
		return codigo;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public Vuelo getVuelo() {
		return vuelo;
	}

	public boolean esUsado() {
		return usado;
	}

	public void marcarComoUsado() {
		this.usado = true;
	}
	
}
